
import React from 'react';

class Dropdown extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			countries : [],
			states : [],
			cities : [],
			selectedCountry : '--Select Country--',
            selectedState : '--Select State--'
           
		};
		
	}
  
	componentDidMount() {
		this.setState({
			countries : [{
                id: 1,
                name: 'USA',
                children: [{
                        id: 1,
                        name: 'California',
                        children: [{
                                id: 1,
                                name: 'Los Angeles'
                            }, {
                                id: 2,
                                name: 'San Diego'
                            }
                        ]
                    }, {
                        id: 2,
                        name: 'Texas',
                        children: [{
                                id: 1,
                                name: 'Houston'
                            }, {
                                id: 2,
                                name: 'Dallas'
                            }
                        ]
                    }, {
                        id: 3,
                        name: 'Florida'
                    }
                ]
            }, {
                id: 2,
                name: 'India',
                children: [{
                        id: 1,
                        name: 'Kerala'
                    }, {
                        id: 2,
                        name: 'Telangana',
                        children: [{
                                id: 1,
                                name: 'Warangal'
                            }, {
                                id: 2,
                                name: 'Hyderabad'
                            }
                        ]
                    }, {
                        id: 3,
                        name: 'Delhi'
                    }
                ]
            }, {
                id: 3,
                name: 'Canada',
                children: [{
                        id: 1,
                        name: 'Toranto'
                    }, {
                        id: 2,
                        name: 'Qubeque'
                    }
                ]
            }
            ]
		});
	}
  
	changeCountry=(event) =>{
		this.setState({selectedCountry: event.target.value});
		this.setState({states : this.state.countries.find(cntry => cntry.name === event.target.value).children});
	}

	changeState=(event)=> {
		this.setState({selectedState: event.target.value});
		const stats = this.state.countries.find(cntry => cntry.name === this.state.selectedCountry).children;
		this.setState({cities : stats.find(stat => stat.name === event.target.value).children});
	}
	
	render() {
        let noCityFound= "--Select City--";
        if (!this.state.cities) {
            noCityFound= "No City Found";
        }
        let selectedCities=  "--Choose City--";
        if (this.state.cities) {
            selectedCities= this.state.cities.map((e, key) => {
                return <option key={key}>{e.name}</option>;
            })
        }
		return (
			<div id="container" style={{marginLeft:"50px", marginTop:"50px"}}>
				<h2 style={{fontSize:"20px", marginBottom:"30px"}}>Country Cascading Dropdown</h2>
	
				<div>
					<label style={{marginRight:"50px", minWidth:"80px"}}>Country:</label>
					<select placeholder="Country" value={this.state.selectedCountry} onChange={this.changeCountry}>
						<option>--Select Country--</option>
						{this.state.countries.map((e, key) => {
							return <option key={key}>{e.name}</option>;
						})}
					</select>
				</div>

				<div>
					<label style={{marginRight:"50px", minWidth:"80px"}}>State</label>
					<select placeholder="State" value={this.state.selectedState} onChange={this.changeState}>
						<option>--Select State--</option>
						{this.state.states.map((e, key) => {
							return <option key={key}>{e.name}</option>;
						})}
					</select>
				</div>
				
				<div>
					<label style={{marginRight:"50px", minWidth:"80px"}}>City</label>
					<select placeholder="City">
                    <option>{noCityFound}</option>
						{selectedCities}
					</select>
				</div>
			</div>
		)
	}
}

export default Dropdown;

